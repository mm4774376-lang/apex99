/* ============================================================
   APEX PURE — js/script.js  (Stage 3)
   Vanilla ES6+, no dependencies, no build step.

   Modules
   01  Config & helpers
   02  Injected state styles (JS-owned states only)
   03  Header scroll state
   04  Mobile navigation
   05  Smooth anchors (+ header-aware offset, focus handling)
   06  Active navigation (IntersectionObserver)
   07  FAQ accordion
   08  Quantity selector
   09  WhatsApp order form
   10  Scroll reveal (IntersectionObserver)
   11  Boot

   WhatsApp setup: set  data-whatsapp-number  on #order-form in
   index.html to the business number in international format
   (digits only, no "+", no leading zeros). Until then the form
   validates but refuses to open WhatsApp.
   ============================================================ */

(() => {
    'use strict';

    /* ----------------------------------------------------------
       01 — CONFIG & HELPERS
       ---------------------------------------------------------- */

    const CONFIG = Object.freeze({
        productName: 'APEX PURE CREATINE MONOHYDRATE POWDER',
        brandName: 'APEX PURE',
        menuBreakpoint: 1025,        // px — mobile toggle is hidden from this width up (see responsive.css)
        headerScrolledAt: 24,        // px scrolled before header gets its "scrolled" state
        quantityFallback: { min: 1, max: 20 },
        businessNumberDigits: { min: 7, max: 15 }, // E.164 range
        customerNumberDigits: { min: 7, max: 15 },
        notesMaxLength: 500,
        faqDuration: 420,
        faqEasing: 'cubic-bezier(0.16, 1, 0.3, 1)'
    });

    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    /** Run a module without letting one failure break the rest of the page. */
    const safely = (name, fn) => {
        try {
            return fn();
        } catch (error) {
            console.error(`[APEX PURE] "${name}" failed to initialise:`, error);
            return null;
        }
    };

    /** Single-line text: strip control / bidi-override characters, collapse whitespace. */
    const cleanLine = (value) =>
        String(value ?? '')
            .replace(/[\u0000-\u001F\u007F\u202A-\u202E\u2066-\u2069]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();

    /** Multi-line text: keep line breaks, strip control / bidi-override characters. */
    const cleanMultiline = (value) =>
        String(value ?? '')
            .replace(/\r\n?/g, '\n')
            .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u202A-\u202E\u2066-\u2069]/g, '')
            .replace(/[ \t]+\n/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();


    /* ----------------------------------------------------------
       02 — INJECTED STATE STYLES
       The shipped CSS has no rules for several JS-driven states
       (hamburger "X", active link, field errors, reveal, status
       message). Those are defined here, scoped to JS-owned
       classes / attributes, so the CSS files stay untouched.
       Colours reuse the existing design tokens.
       ---------------------------------------------------------- */

    function injectStateStyles() {
        if ($('#apex-js-state-styles')) return;

        const style = document.createElement('style');
        style.id = 'apex-js-state-styles';
        style.textContent = `
/* Hamburger -> close icon (bars are 2px tall with a 5px gap = 7px travel) */
.mobile-menu-toggle[aria-expanded="true"] .menu-bar--top { transform: translateY(7px) rotate(45deg); }
.mobile-menu-toggle[aria-expanded="true"] .menu-bar--mid { opacity: 0; transform: scaleX(0.2); }
.mobile-menu-toggle[aria-expanded="true"] .menu-bar--bot { transform: translateY(-7px) rotate(-45deg); }

/* Mobile menu: staggered link entrance (delay index set from data-stagger-index) */
:root .mobile-menu .mobile-nav-links > li {
    opacity: 0;
    translate: 0 14px;
    transition: opacity 0.5s var(--ease-out, ease), translate 0.5s var(--ease-out, ease);
}
:root .mobile-menu[aria-hidden="false"] .mobile-nav-links > li {
    opacity: 1;
    translate: 0 0;
    transition-delay: calc(var(--apex-i, 0) * 60ms + 120ms);
}

/* Active section link */
.nav-link[aria-current="location"] { color: var(--color-white); }
.nav-link[aria-current="location"]::after { width: 100%; }
.mobile-nav-link[aria-current="location"]:not(.mobile-nav-cta) { color: var(--color-gold); }

/* Scroll reveal (only ever applied to below-the-fold elements) */
:root .apex-reveal {
    opacity: 0;
    translate: 0 28px;
    transition: opacity 0.8s var(--ease-out, ease), translate 0.8s var(--ease-out, ease);
    will-change: opacity, translate;
}
:root .apex-reveal.apex-reveal--in { opacity: 1; translate: 0 0; }

/* Quantity buttons at their limits (aria-disabled keeps keyboard focus alive) */
.quantity-btn[aria-disabled="true"] { opacity: 0.35; cursor: not-allowed; }

/* Keep scrolled-to / focused form elements clear of the fixed header (~84px) */
.order-form .form-input,
.order-form .form-select,
.order-form .form-textarea,
.order-form .quantity-selector,
.apex-form-status { scroll-margin-top: 7rem; }

/* Form validation */
.apex-field-error {
    margin-top: 0.5rem;
    font-family: var(--font-body, inherit);
    font-size: 0.8rem;
    line-height: 1.45;
    color: #F87171;
}
.apex-field-error[hidden] { display: none; }
.form-input[aria-invalid="true"],
.form-select[aria-invalid="true"],
.form-textarea[aria-invalid="true"],
.quantity-selector.apex-invalid { border-color: #F87171; }

/* Form status message */
.apex-form-status {
    margin-top: var(--space-md, 1.25rem);
    padding: 0.9rem 1.1rem;
    border: 1px solid var(--color-border);
    border-left: 3px solid var(--color-gold);
    border-radius: var(--radius-sm, 4px);
    background-color: var(--color-white-05);
    font-family: var(--font-body, inherit);
    font-size: 0.875rem;
    line-height: 1.65;
    color: var(--color-white-70);
}
.apex-form-status:empty { margin: 0; padding: 0; border: 0; }
.apex-form-status[data-state="error"] { border-left-color: #F87171; }
.apex-form-status strong { display: block; margin-bottom: 0.2rem; color: var(--color-white); font-weight: 600; }
.apex-form-status a { color: var(--color-gold); text-decoration: underline; text-underline-offset: 3px; }
`;
        document.head.appendChild(style);
    }


    /* ----------------------------------------------------------
       03 — HEADER SCROLL STATE
       CSS already styles .site-header[data-nav-state="scrolled"].
       ---------------------------------------------------------- */

    function initHeaderState() {
        const header = $('#site-header');
        if (!header) return;

        let ticking = false;
        let current = null;

        const update = () => {
            ticking = false;
            // While the mobile menu is open the "scrolled" state is suspended: its
            // backdrop-filter would make the header the containing block of the
            // fixed full-screen overlay and shrink the overlay to header height.
            const next = header.hasAttribute('data-menu-open')
                ? 'menu-open'
                : (window.scrollY > CONFIG.headerScrolledAt ? 'scrolled' : 'top');
            if (next !== current) {
                current = next;
                header.setAttribute('data-nav-state', next);
            }
        };

        header.addEventListener('apex:header-refresh', update);

        // Passive + rAF-throttled; only writes to the DOM when the state flips.
        window.addEventListener('scroll', () => {
            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(update);
            }
        }, { passive: true });

        update();
    }


    /* ----------------------------------------------------------
       04 — MOBILE NAVIGATION
       ---------------------------------------------------------- */

    function initMobileMenu() {
        const toggle = $('#mobile-menu-toggle');
        const menu = $('#mobile-menu');
        if (!toggle || !menu) return;

        const header = $('#site-header');
        const links = $$('.mobile-nav-link', menu);
        const desktopQuery = window.matchMedia(`(min-width: ${CONFIG.menuBreakpoint}px)`);

        const LABEL_OPEN = 'Open navigation menu';
        const LABEL_CLOSE = 'Close navigation menu';

        // Everything behind the overlay is made inert while the menu is open,
        // so focus and assistive tech stay inside the menu.
        const inertTargets = [$('#main-content'), $('#site-footer'), $('.nav-brand')].filter(Boolean);

        let isOpen = false;
        let scrollLock = null;

        // Per-link stagger index for the entrance transition (see injected CSS).
        $$('[data-stagger-index]', menu).forEach((item) => {
            item.style.setProperty('--apex-i', item.getAttribute('data-stagger-index'));
        });

        /** Lock page scroll without a layout jump when a scrollbar disappears. */
        function lockScroll(lock) {
            const html = document.documentElement;
            const body = document.body;

            if (lock && !scrollLock) {
                const scrollbar = window.innerWidth - html.clientWidth;
                scrollLock = {
                    htmlOverflow: html.style.overflow,
                    bodyOverflow: body.style.overflow,
                    bodyPadding: body.style.paddingRight,
                    headerPadding: header ? header.style.paddingRight : ''
                };
                html.style.overflow = 'hidden';
                body.style.overflow = 'hidden';
                if (scrollbar > 0) {
                    body.style.paddingRight = `${scrollbar}px`;
                    if (header) header.style.paddingRight = `${scrollbar}px`;
                }
            } else if (!lock && scrollLock) {
                html.style.overflow = scrollLock.htmlOverflow;
                body.style.overflow = scrollLock.bodyOverflow;
                body.style.paddingRight = scrollLock.bodyPadding;
                if (header) header.style.paddingRight = scrollLock.headerPadding;
                scrollLock = null;
            }
        }

        function setOpen(next, { restoreFocus = true } = {}) {
            if (next === isOpen) return;
            isOpen = next;

            toggle.setAttribute('aria-expanded', String(next));
            toggle.setAttribute('aria-label', next ? LABEL_CLOSE : LABEL_OPEN);
            menu.setAttribute('aria-hidden', String(!next));
            inertTargets.forEach((el) => el.toggleAttribute('inert', next));
            lockScroll(next);
            setHeaderMenuFlag(next);

            if (next) {
                // The overlay is still visibility:hidden on the first frame, so focus
                // may be refused; retry once. Never steal focus if the user already moved.
                const focusFirst = () => { if (links[0]) links[0].focus({ preventScroll: true }); };
                window.requestAnimationFrame(() => {
                    if (!isOpen) return;
                    focusFirst();
                    if (document.activeElement === toggle) {
                        window.setTimeout(() => {
                            if (isOpen && document.activeElement === toggle) focusFirst();
                        }, 80);
                    }
                });
            } else if (restoreFocus) {
                toggle.focus({ preventScroll: true });
            }
        }

        /** Flag the header while the menu is open; clear it only after the fade-out ends. */
        function setHeaderMenuFlag(open) {
            if (!header) return;
            if (open) {
                header.setAttribute('data-menu-open', '');
                header.dispatchEvent(new Event('apex:header-refresh'));
            } else {
                window.setTimeout(() => {
                    if (isOpen) return; // re-opened in the meantime
                    header.removeAttribute('data-menu-open');
                    header.dispatchEvent(new Event('apex:header-refresh'));
                }, 450);
            }
        }

        // Sync initial markup state.
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', LABEL_OPEN);
        menu.setAttribute('aria-hidden', 'true');

        toggle.addEventListener('click', () => setOpen(!isOpen));

        // A navigation link closes the menu (anchor scrolling is handled by initSmoothAnchors).
        links.forEach((link) => {
            link.addEventListener('click', () => setOpen(false, { restoreFocus: false }));
        });

        // Click on the empty overlay area closes the menu.
        menu.addEventListener('click', (event) => {
            if (event.target === menu || event.target.classList.contains('mobile-menu-inner')) {
                setOpen(false);
            }
        });

        document.addEventListener('keydown', (event) => {
            if (!isOpen) return;

            if (event.key === 'Escape') {
                event.preventDefault();
                setOpen(false);
                return;
            }

            // Keep Tab inside toggle + links.
            if (event.key === 'Tab') {
                const focusable = [toggle, ...links];
                const first = focusable[0];
                const last = focusable[focusable.length - 1];
                if (event.shiftKey && document.activeElement === first) {
                    event.preventDefault();
                    last.focus();
                } else if (!event.shiftKey && document.activeElement === last) {
                    event.preventDefault();
                    first.focus();
                }
            }
        });

        // Resizing to desktop while open must never leave the page locked.
        const onViewportChange = (event) => {
            if (event.matches && isOpen) setOpen(false, { restoreFocus: false });
        };
        if (desktopQuery.addEventListener) {
            desktopQuery.addEventListener('change', onViewportChange);
        } else {
            desktopQuery.addListener(onViewportChange); // older Safari
        }
    }


    /* ----------------------------------------------------------
       05 — SMOOTH ANCHORS
       ---------------------------------------------------------- */

    function initSmoothAnchors() {
        const header = $('#site-header');

        document.addEventListener('click', (event) => {
            if (event.defaultPrevented || event.button !== 0) return;
            if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

            const link = event.target.closest('a[href^="#"]');
            if (!link) return;

            const hash = link.getAttribute('href');
            if (!hash || hash.length < 2) return; // bare "#" placeholders keep native behaviour

            let id;
            try {
                id = decodeURIComponent(hash.slice(1));
            } catch (_) {
                return;
            }

            const target = document.getElementById(id);
            if (!target) return;

            event.preventDefault();

            // Land the section's content just below the fixed header.
            // Sections carry large top padding, so subtract it from the offset.
            let top = 0;
            if (id !== 'hero') {
                const padding = parseFloat(window.getComputedStyle(target).paddingTop) || 0;
                const headerHeight = header ? header.offsetHeight : 0;
                const offset = Math.max(0, headerHeight + 16 - padding);
                top = Math.max(0, target.getBoundingClientRect().top + window.scrollY - offset);
            }

            window.scrollTo({ top, behavior: reducedMotion.matches ? 'auto' : 'smooth' });

            try {
                if (window.location.hash !== hash) window.history.pushState(null, '', hash);
            } catch (_) { /* file:// or sandboxed contexts */ }

            // Move focus to the destination for keyboard / screen-reader users.
            if (!target.hasAttribute('tabindex')) {
                target.setAttribute('tabindex', '-1');
                target.style.outline = 'none';
                target.addEventListener('blur', () => {
                    target.removeAttribute('tabindex');
                    target.style.outline = '';
                }, { once: true });
            }
            target.focus({ preventScroll: true });
        });
    }


    /* ----------------------------------------------------------
       06 — ACTIVE NAVIGATION
       A 1%-tall band at ~45% of the viewport decides the current section.
       ---------------------------------------------------------- */

    function initActiveNav() {
        if (!('IntersectionObserver' in window)) return;

        const linksById = new Map();
        $$('[data-nav-link], .mobile-nav-link').forEach((link) => {
            const href = link.getAttribute('href') || '';
            if (!href.startsWith('#') || href.length < 2) return;
            const id = href.slice(1);
            if (!linksById.has(id)) linksById.set(id, []);
            linksById.get(id).push(link);
        });
        if (!linksById.size) return;

        let currentId = null;
        const setCurrent = (id) => {
            if (id === currentId) return;
            currentId = id;
            linksById.forEach((links, key) => {
                links.forEach((link) => {
                    if (key === id) link.setAttribute('aria-current', 'location');
                    else link.removeAttribute('aria-current');
                });
            });
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) setCurrent(entry.target.id);
            });
        }, { rootMargin: '-45% 0px -54% 0px', threshold: 0 });

        // Sections without a nav link (hero, philosophy, ...) clear the active state.
        $$('main section[id]').forEach((section) => observer.observe(section));
    }


    /* ----------------------------------------------------------
       07 — FAQ ACCORDION
       ---------------------------------------------------------- */

    function initFaq() {
        const triggers = $$('.faq-trigger');
        if (!triggers.length) return;

        const animations = new WeakMap();

        const panelFor = (trigger) => {
            const id = trigger.getAttribute('aria-controls');
            return (id && document.getElementById(id)) ||
                (trigger.closest('.faq-item') && $('.faq-answer', trigger.closest('.faq-item'))) ||
                null;
        };

        const stopAnimation = (panel) => {
            const running = animations.get(panel);
            if (running) {
                running.cancel();
                animations.delete(panel);
            }
        };

        /** Snapshot of the panel's current box so interrupted animations continue smoothly. */
        const snapshot = (panel) => {
            if (panel.hidden) return { height: 0, opacity: 0, padding: 0 };
            const style = window.getComputedStyle(panel);
            return {
                height: panel.getBoundingClientRect().height,
                opacity: parseFloat(style.opacity),
                padding: parseFloat(style.paddingBottom) || 0
            };
        };

        const frame = (box) => ({
            height: `${box.height}px`,
            opacity: box.opacity,
            paddingBottom: `${box.padding}px`
        });

        const timing = { duration: CONFIG.faqDuration, easing: CONFIG.faqEasing };

        function expand(panel) {
            const from = snapshot(panel);
            stopAnimation(panel);
            panel.hidden = false;
            if (reducedMotion.matches) return;

            // Natural (auto) size, measured with the panel visible and un-animated.
            const to = {
                height: panel.offsetHeight,
                opacity: 1,
                padding: parseFloat(window.getComputedStyle(panel).paddingBottom) || 0
            };

            const animation = panel.animate([frame(from), frame(to)], timing);
            animations.set(panel, animation);
            animation.onfinish = () => animations.delete(panel);
        }

        function collapse(panel) {
            if (panel.hidden) return;
            const from = snapshot(panel);
            stopAnimation(panel);

            if (reducedMotion.matches || from.height === 0) {
                panel.hidden = true;
                return;
            }

            const animation = panel.animate(
                [frame(from), frame({ height: 0, opacity: 0, padding: 0 })],
                { ...timing, fill: 'forwards' }
            );
            animations.set(panel, animation);
            animation.onfinish = () => {
                panel.hidden = true;
                animation.cancel(); // drop the forwards-fill
                animations.delete(panel);
            };
        }

        function setExpanded(trigger, expanded) {
            const panel = panelFor(trigger);
            trigger.setAttribute('aria-expanded', String(expanded));
            if (!panel) return;
            if (expanded) expand(panel);
            else collapse(panel);
        }

        // Normalise initial state: valid aria-controls, only one panel open.
        let openFound = false;
        triggers.forEach((trigger) => {
            const panel = panelFor(trigger);
            if (!panel) return;
            if (!trigger.getAttribute('aria-controls')) {
                if (!panel.id) panel.id = `${trigger.id || 'faq'}-answer`;
                trigger.setAttribute('aria-controls', panel.id);
            }
            let open = trigger.getAttribute('aria-expanded') === 'true';
            if (open && openFound) open = false;
            if (open) openFound = true;
            trigger.setAttribute('aria-expanded', String(open));
            panel.hidden = !open;
        });

        const root = $('.faq-accordion') || document;

        root.addEventListener('click', (event) => {
            const trigger = event.target.closest('.faq-trigger');
            if (!trigger || !triggers.includes(trigger)) return;

            const willOpen = trigger.getAttribute('aria-expanded') !== 'true';
            if (willOpen) {
                triggers.forEach((other) => {
                    if (other !== trigger && other.getAttribute('aria-expanded') === 'true') {
                        setExpanded(other, false);
                    }
                });
            }
            setExpanded(trigger, willOpen);
        });

        // Enter / Space work natively on <button>; add the standard accordion arrow-key roving.
        root.addEventListener('keydown', (event) => {
            const trigger = event.target.closest('.faq-trigger');
            if (!trigger) return;

            const index = triggers.indexOf(trigger);
            let nextIndex = null;
            if (event.key === 'ArrowDown') nextIndex = (index + 1) % triggers.length;
            else if (event.key === 'ArrowUp') nextIndex = (index - 1 + triggers.length) % triggers.length;
            else if (event.key === 'Home') nextIndex = 0;
            else if (event.key === 'End') nextIndex = triggers.length - 1;

            if (nextIndex !== null) {
                event.preventDefault();
                triggers[nextIndex].focus();
            }
        });
    }


    /* ----------------------------------------------------------
       08 — QUANTITY SELECTOR
       Returns a small API used by the order form.
       ---------------------------------------------------------- */

    function initQuantity() {
        const input = $('#order-quantity');
        if (!input) return null;

        const minus = $('.quantity-btn--minus');
        const plus = $('.quantity-btn--plus');
        const summaries = $$('[data-summary="quantity"]');

        // HTML attributes are the source of truth; fall back to 1–20.
        const attrMin = parseInt(input.getAttribute('min'), 10);
        const attrMax = parseInt(input.getAttribute('max'), 10);
        const MIN = Number.isFinite(attrMin) && attrMin >= 1 ? attrMin : CONFIG.quantityFallback.min;
        const MAX = Number.isFinite(attrMax) && attrMax >= MIN ? attrMax : CONFIG.quantityFallback.max;

        const clamp = (n) => Math.min(MAX, Math.max(MIN, n));

        const initial = parseInt(input.value, 10);
        let lastValid = Number.isFinite(initial) ? clamp(initial) : MIN;

        /** Push the committed value to the summary and the +/- buttons. */
        function render() {
            summaries.forEach((el) => { el.textContent = String(lastValid); });
            if (minus) minus.setAttribute('aria-disabled', String(lastValid <= MIN));
            if (plus) plus.setAttribute('aria-disabled', String(lastValid >= MAX));
        }

        /** Set an exact, valid quantity everywhere. */
        function set(value) {
            lastValid = clamp(Math.trunc(value));
            input.value = String(lastValid);
            render();
        }

        /** Resolve whatever is in the field into a valid quantity (blur / change / submit). */
        function commit() {
            const parsed = parseInt(input.value, 10);
            set(Number.isFinite(parsed) ? parsed : lastValid);
        }

        // Typing: fix what can be fixed immediately; tolerate "" and "0" while editing.
        input.addEventListener('input', () => {
            const raw = input.value;
            if (raw === '') return;
            const n = Number(raw);
            if (!Number.isFinite(n) || n === 0) return;

            const fixed = clamp(Math.trunc(n)); // decimals truncated, negatives -> min, large -> max
            if (String(fixed) !== raw) input.value = String(fixed);
            lastValid = fixed;
            render();
        });

        input.addEventListener('change', commit);
        input.addEventListener('blur', commit);

        // Block characters that make no sense for a whole, positive quantity.
        input.addEventListener('keydown', (event) => {
            if (['e', 'E', '+', '-', '.', ','].includes(event.key)) event.preventDefault();
        });

        // Scrolling the page over a focused number field must not change the value.
        input.addEventListener('wheel', () => input.blur(), { passive: true });

        const step = (delta) => {
            const current = parseInt(input.value, 10);
            const base = Number.isFinite(current) && current >= MIN ? current : lastValid;
            set(base + delta);
        };

        if (minus) {
            minus.addEventListener('click', () => {
                if (minus.getAttribute('aria-disabled') !== 'true') step(-1);
            });
        }
        if (plus) {
            plus.addEventListener('click', () => {
                if (plus.getAttribute('aria-disabled') !== 'true') step(1);
            });
        }

        // Browsers may restore form values (back/forward cache, reload) — re-sync the summary.
        window.addEventListener('pageshow', (event) => {
            if (event.persisted) commit();
        });

        set(lastValid);

        return { commit, getValue: () => lastValid, min: MIN, max: MAX };
    }


    /* ----------------------------------------------------------
       09 — WHATSAPP ORDER FORM
       Everything stays in the browser; the only network action is the
       user's own navigation to WhatsApp click-to-chat in a new tab.
       ---------------------------------------------------------- */

    /**
     * Validate the business number from data-whatsapp-number.
     * Returns digits only (wa.me format) or null when missing / placeholder / malformed.
     */
    function parseBusinessNumber(raw) {
        const value = String(raw ?? '').trim();
        if (!value) return null;
        if (!/^\+?[\d\s().-]+$/.test(value)) return null; // letters => "PHONE_NUMBER_PLACEHOLDER" etc.

        let digits = value.replace(/\D/g, '');
        if (digits.startsWith('00')) digits = digits.slice(2); // 00-prefixed international format
        if (digits.startsWith('0')) return null;               // local format, country code missing

        const { min, max } = CONFIG.businessNumberDigits;
        return digits.length >= min && digits.length <= max ? digits : null;
    }

    function buildOrderMessage({ name, whatsapp, country, quantity, notes }) {
        const lines = [
            `${CONFIG.brandName} — NEW ORDER`,
            '',
            'Customer Details:',
            `Name: ${name}`,
            `WhatsApp: ${whatsapp}`,
            `Country: ${country}`,
            '',
            'Order Details:',
            `Product: ${CONFIG.productName}`,
            `Quantity: ${quantity}`
        ];
        if (notes) lines.push('', 'Additional Notes:', notes);
        lines.push('', `Thank you for choosing ${CONFIG.brandName}.`);
        return lines.join('\n');
    }

    function initOrderForm(quantityApi) {
        const form = $('#order-form');
        if (!form) return;

        const fields = {
            name: $('#order-name'),
            whatsapp: $('#order-whatsapp'),
            country: $('#order-country'),
            quantity: $('#order-quantity'),
            notes: $('#order-notes')
        };
        const submitButton = $('.order-submit', form);

        // Required fields in DOM order (this is also the focus order for errors).
        const validators = {
            name(field) {
                const value = cleanLine(field.value);
                const min = field.minLength > 0 ? field.minLength : 2;
                const max = field.maxLength > 0 ? field.maxLength : 100;
                if (!value) return 'Please enter your full name.';
                if (value.length < min) return `Your name should be at least ${min} characters.`;
                if (value.length > max) return `Your name should be ${max} characters or fewer.`;
                return '';
            },
            whatsapp(field) {
                const value = field.value.trim();
                if (!value) return 'Please enter your WhatsApp number.';
                const digits = value.replace(/\D/g, '').length;
                const { min, max } = CONFIG.customerNumberDigits;
                // validity.patternMismatch applies the native pattern attribute.
                if (field.validity.patternMismatch || digits < min || digits > max) {
                    return 'Enter a valid number with country code, e.g. +1 234 567 8900.';
                }
                return '';
            },
            country(field) {
                return field.value ? '' : 'Please select your country.';
            },
            quantity(field) {
                const min = quantityApi ? quantityApi.min : CONFIG.quantityFallback.min;
                const max = quantityApi ? quantityApi.max : CONFIG.quantityFallback.max;
                if (field.value === '') return 'Please enter a quantity.';
                const n = Number(field.value);
                if (!Number.isInteger(n) || n < min || n > max) {
                    return `Quantity must be a whole number from ${min} to ${max}.`;
                }
                return '';
            }
        };
        const keys = Object.keys(validators).filter((key) => fields[key]);
        const keyByElement = new Map(keys.map((key) => [fields[key], key]));
        const touched = new Set();

        // --- Inline error + status elements (created once, text set via textContent only) ---
        const errorEls = {};
        keys.forEach((key) => {
            const field = fields[key];
            const group = field.closest('.form-group') || field.parentElement;
            const error = document.createElement('p');
            error.className = 'apex-field-error';
            error.id = `${field.id}-error`;
            error.hidden = true;
            group.appendChild(error);
            errorEls[key] = error;
        });

        const status = document.createElement('div');
        status.className = 'apex-form-status';
        status.setAttribute('role', 'status');
        status.setAttribute('aria-live', 'polite');
        if (submitButton && submitButton.parentNode) submitButton.parentNode.insertBefore(status, submitButton);
        else form.appendChild(status);

        function setFieldError(key, message) {
            const field = fields[key];
            const error = errorEls[key];
            const describedBy = (field.getAttribute('aria-describedby') || '')
                .split(/\s+/).filter((token) => token && token !== error.id);

            error.textContent = message;
            error.hidden = !message;

            if (message) {
                field.setAttribute('aria-invalid', 'true');
                describedBy.push(error.id);
            } else {
                field.removeAttribute('aria-invalid');
            }
            if (describedBy.length) field.setAttribute('aria-describedby', describedBy.join(' '));
            else field.removeAttribute('aria-describedby');

            if (key === 'quantity') {
                const selector = field.closest('.quantity-selector');
                if (selector) selector.classList.toggle('apex-invalid', Boolean(message));
            }
        }

        function validateField(key) {
            const message = validators[key](fields[key]);
            setFieldError(key, message);
            return !message;
        }

        function clearStatus() {
            status.replaceChildren();
            status.removeAttribute('data-state');
        }

        function showStatus(state, title, body, link) {
            const heading = document.createElement('strong');
            heading.textContent = title;
            const text = document.createElement('span');
            text.textContent = body;
            status.replaceChildren(heading, text);
            if (link) {
                status.append(' ');
                const anchor = document.createElement('a');
                anchor.href = link.href;
                anchor.target = '_blank';
                anchor.rel = 'noopener noreferrer';
                anchor.textContent = link.label;
                status.appendChild(anchor);
            }
            status.setAttribute('data-state', state);
            status.scrollIntoView({ block: 'nearest', behavior: reducedMotion.matches ? 'auto' : 'smooth' });
        }

        // --- Live feedback: validate on blur once a field has content, then on every edit ---
        form.addEventListener('input', (event) => {
            const key = keyByElement.get(event.target);
            if (key && touched.has(key)) validateField(key);
            clearStatus(); // any edit makes a previous status message stale
        });

        form.addEventListener('change', (event) => {
            const key = keyByElement.get(event.target);
            if (key && touched.has(key)) validateField(key);
        });

        form.addEventListener('focusout', (event) => {
            const key = keyByElement.get(event.target);
            if (!key) return;
            if (key === 'quantity') return; // quantity self-corrects on blur (see initQuantity)
            if (event.target.value !== '') {
                touched.add(key);
                validateField(key);
            }
        });

        // --- Submit ---
        let busy = false;

        form.addEventListener('submit', (event) => {
            event.preventDefault();
            if (busy) return;

            clearStatus();
            if (quantityApi) quantityApi.commit(); // resolve "" / "0" typed values before validating

            // 1. Validate every required field and focus the first problem.
            let firstInvalid = null;
            keys.forEach((key) => {
                touched.add(key);
                if (!validateField(key) && !firstInvalid) firstInvalid = fields[key];
            });
            if (firstInvalid) {
                firstInvalid.focus();
                return;
            }

            // 2. The business number must be configured before anything can be sent.
            const businessNumber = parseBusinessNumber(form.getAttribute('data-whatsapp-number'));
            if (!businessNumber) {
                console.warn(
                    '[APEX PURE] WhatsApp number is not configured. Set data-whatsapp-number on #order-form ' +
                    'to the business number in international format (digits only).'
                );
                showStatus(
                    'error',
                    'WhatsApp ordering is not active yet.',
                    'The business WhatsApp number has not been configured, so your order cannot be sent. ' +
                    'Nothing has been opened or submitted. Please contact APEX PURE through another channel or try again later.'
                );
                return;
            }

            // 3. Build the message from sanitised values and open click-to-chat.
            const countryOption = fields.country.options[fields.country.selectedIndex];
            const message = buildOrderMessage({
                name: cleanLine(fields.name.value),
                whatsapp: cleanLine(fields.whatsapp.value),
                country: cleanLine(countryOption ? countryOption.text : fields.country.value),
                quantity: quantityApi ? quantityApi.getValue() : parseInt(fields.quantity.value, 10),
                notes: fields.notes ? cleanMultiline(fields.notes.value).slice(0, CONFIG.notesMaxLength) : ''
            });

            const url = `https://wa.me/${businessNumber}?text=${encodeURIComponent(message)}`;

            // Opened without the "noopener" feature so a blocked pop-up can be detected
            // (it would otherwise always return null); the opener link is severed right away.
            const opened = window.open(url, '_blank');

            busy = true;
            window.setTimeout(() => { busy = false; }, 1200);

            if (opened) {
                opened.opener = null;
                showStatus(
                    'info',
                    'WhatsApp has been opened in a new tab.',
                    'Review your order message and press Send there. Your order is only placed once you send the message.'
                );
            } else {
                showStatus(
                    'error',
                    'Your browser blocked the new tab.',
                    'Your order has not been sent yet.',
                    { href: url, label: 'Open WhatsApp with my order message' }
                );
            }
        });
    }


    /* ----------------------------------------------------------
       10 — SCROLL REVEAL
       Only elements that start below the fold are hidden, and only
       after JS is running, so there is no content flash and nothing
       stays hidden if JS fails. Classes are removed once finished so
       the element's own CSS (hover transforms etc.) resumes.
       ---------------------------------------------------------- */

    function initReveal() {
        if (reducedMotion.matches || !('IntersectionObserver' in window)) return;

        const SELECTOR = [
            '[data-animate="fade-up"]',
            '[data-animate="stagger"]',
            '[data-animate="headline-reveal"]',
            '[data-animate="word-reveal"]',
            '[data-animate="product-reveal"]',
            '[data-animate="product-showcase-reveal"]'
        ].join(',');

        const viewportHeight = window.innerHeight || document.documentElement.clientHeight;

        // Top-most matches only (nested ones appear with their parent), and only elements that
        // are completely below the fold — anything already on screen is never hidden (no flash).
        const targets = $$(SELECTOR).filter((el) => {
            if (el.parentElement && el.parentElement.closest(SELECTOR)) return false;
            return el.getBoundingClientRect().top >= viewportHeight;
        });
        if (!targets.length) return;

        const clear = (el) => {
            el.classList.remove('apex-reveal', 'apex-reveal--in');
            el.style.transitionDelay = '';
        };

        const delayFor = (el) => {
            const explicit = parseInt(el.getAttribute('data-delay'), 10);
            if (Number.isFinite(explicit)) return Math.min(explicit, 1200);
            const index = parseInt(el.getAttribute('data-stagger-index'), 10);
            return Number.isFinite(index) ? Math.min(index * 90, 450) : 0;
        };

        // Each element is revealed the first time it enters the viewport. Elements skipped by a
        // long jump simply reveal when the user scrolls back to them.
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) return;
                const el = entry.target;
                observer.unobserve(el);

                const delay = delayFor(el);
                el.style.transitionDelay = `${delay}ms`;
                window.requestAnimationFrame(() => el.classList.add('apex-reveal--in'));
                window.setTimeout(() => clear(el), delay + 1000);
            });
        }, { threshold: 0.01, rootMargin: '0px 0px -10% 0px' });

        targets.forEach((el) => {
            el.classList.add('apex-reveal');
            observer.observe(el);
        });

        // Never print or save a half-hidden page.
        window.addEventListener('beforeprint', () => {
            targets.forEach(clear);
            observer.disconnect();
        });
    }


    /* ----------------------------------------------------------
       Footer year (existing hook: [data-dynamic="copyright-year"])
       ---------------------------------------------------------- */

    function initCopyrightYear() {
        $$('[data-dynamic="copyright-year"]').forEach((el) => {
            el.textContent = String(new Date().getFullYear());
        });
    }


    /* ----------------------------------------------------------
       11 — BOOT
       ---------------------------------------------------------- */

    function boot() {
        safely('state styles', injectStateStyles);
        safely('header state', initHeaderState);
        safely('mobile menu', initMobileMenu);
        safely('smooth anchors', initSmoothAnchors);
        safely('active nav', initActiveNav);
        safely('faq', initFaq);
        const quantityApi = safely('quantity', initQuantity);
        safely('order form', () => initOrderForm(quantityApi));
        safely('copyright year', initCopyrightYear);
        safely('scroll reveal', initReveal);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }
})();
